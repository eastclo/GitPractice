package Controller;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/*
 임시로 만들었습니다. 삭제될 수도 있습니다.
 1. 시작하자마자 Repository 목록을 받아오는 것과
 2. load 버튼을 누르면 파일을 받아오는 것 중에
 "load 버튼으로 파일을 받아올 경우"의 리스너입니다.
 */

public class LoadClickListener implements MouseListener {

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
